// Storage manager for FileShare Community
class StorageManager {
    constructor() {
        this.users = this.loadUsers();
        this.categories = this.loadCategories();
        this.posts = this.loadPosts();
        this.currentUser = this.loadCurrentUser();
        
        // Initialize default data if empty
        this.initializeDefaultData();
    }

    // User management
    loadUsers() {
        const users = localStorage.getItem('fileshare_users');
        return users ? JSON.parse(users) : [];
    }

    saveUsers() {
        localStorage.setItem('fileshare_users', JSON.stringify(this.users));
    }

    createUser(user) {
        this.users.push(user);
        this.saveUsers();
        return user;
    }

    updateUser(userId, updates) {
        const userIndex = this.users.findIndex(u => u.id === userId);
        if (userIndex !== -1) {
            this.users[userIndex] = { ...this.users[userIndex], ...updates };
            this.saveUsers();
            return this.users[userIndex];
        }
        return null;
    }

    deleteUser(userId) {
        const userIndex = this.users.findIndex(u => u.id === userId);
        if (userIndex !== -1) {
            this.users.splice(userIndex, 1);
            this.saveUsers();
            return true;
        }
        return false;
    }

    getUserById(userId) {
        return this.users.find(u => u.id === userId);
    }

    getUserByEmail(email) {
        return this.users.find(u => u.email === email);
    }

    userExists(email) {
        return this.users.some(u => u.email === email);
    }

    authenticateUser(email, password) {
        const user = this.users.find(u => u.email === email && u.password === password && u.isActive);
        return user || null;
    }

    getAllUsers() {
        return this.users.filter(u => u.isActive);
    }

    // Current user session
    setCurrentUser(user) {
        this.currentUser = user;
        localStorage.setItem('fileshare_current_user', JSON.stringify(user));
    }

    getCurrentUser() {
        return this.currentUser;
    }

    loadCurrentUser() {
        const user = localStorage.getItem('fileshare_current_user');
        return user ? JSON.parse(user) : null;
    }

    clearCurrentUser() {
        this.currentUser = null;
        localStorage.removeItem('fileshare_current_user');
    }

    // Category management
    loadCategories() {
        const categories = localStorage.getItem('fileshare_categories');
        return categories ? JSON.parse(categories) : [];
    }

    saveCategories() {
        localStorage.setItem('fileshare_categories', JSON.stringify(this.categories));
    }

    createCategory(category) {
        this.categories.push(category);
        this.saveCategories();
        return category;
    }

    updateCategory(categoryId, updates) {
        const categoryIndex = this.categories.findIndex(c => c.id === categoryId);
        if (categoryIndex !== -1) {
            this.categories[categoryIndex] = { ...this.categories[categoryIndex], ...updates };
            this.saveCategories();
            return this.categories[categoryIndex];
        }
        return null;
    }

    deleteCategory(categoryId) {
        const categoryIndex = this.categories.findIndex(c => c.id === categoryId);
        if (categoryIndex !== -1) {
            this.categories.splice(categoryIndex, 1);
            this.saveCategories();
            
            // Also delete all posts in this category
            this.posts = this.posts.filter(p => p.categoryId !== categoryId);
            this.savePosts();
            
            return true;
        }
        return false;
    }

    getCategoryById(categoryId) {
        return this.categories.find(c => c.id === categoryId);
    }

    getAllCategories() {
        return this.categories;
    }

    // Post management
    loadPosts() {
        const posts = localStorage.getItem('fileshare_posts');
        return posts ? JSON.parse(posts) : [];
    }

    savePosts() {
        localStorage.setItem('fileshare_posts', JSON.stringify(this.posts));
    }

    createPost(post) {
        this.posts.push(post);
        this.savePosts();
        return post;
    }

    updatePost(postId, updates) {
        const postIndex = this.posts.findIndex(p => p.id === postId);
        if (postIndex !== -1) {
            this.posts[postIndex] = { ...this.posts[postIndex], ...updates };
            this.savePosts();
            return this.posts[postIndex];
        }
        return null;
    }

    deletePost(postId) {
        const postIndex = this.posts.findIndex(p => p.id === postId);
        if (postIndex !== -1) {
            this.posts.splice(postIndex, 1);
            this.savePosts();
            return true;
        }
        return false;
    }

    getPostById(postId) {
        return this.posts.find(p => p.id === postId);
    }

    getPostsByCategory(categoryId) {
        return this.posts.filter(p => p.categoryId === categoryId);
    }

    getPostsByUser(userId) {
        return this.posts.filter(p => p.userId === userId);
    }

    getAllPosts() {
        return this.posts;
    }

    // Initialize default data
    initializeDefaultData() {
        // Create default admin user if no users exist
        if (this.users.length === 0) {
            const defaultAdmin = {
                id: 'admin_001',
                username: 'admin',
                email: 'admin@fileshare.com',
                password: 'admin123',
                role: 'admin',
                createdAt: new Date().toISOString(),
                isActive: true
            };
            this.createUser(defaultAdmin);
        }

        // Create default categories if none exist
        if (this.categories.length === 0) {
            const defaultCategories = [
                {
                    id: 'cat_001',
                    name: 'Documentos',
                    description: 'Documentos e materiais educacionais',
                    createdAt: new Date().toISOString(),
                    createdBy: 'admin_001'
                },
                {
                    id: 'cat_002',
                    name: 'Imagens',
                    description: 'Imagens e recursos visuais',
                    createdAt: new Date().toISOString(),
                    createdBy: 'admin_001'
                },
                {
                    id: 'cat_003',
                    name: 'Vídeos',
                    description: 'Vídeos educacionais e tutoriais',
                    createdAt: new Date().toISOString(),
                    createdBy: 'admin_001'
                }
            ];
            
            defaultCategories.forEach(category => {
                this.createCategory(category);
            });
        }
    }

    // Utility methods
    generateId() {
        return Date.now().toString(36) + Math.random().toString(36).substr(2);
    }

    // Export/Import functionality
    exportData() {
        return {
            users: this.users,
            categories: this.categories,
            posts: this.posts,
            exportedAt: new Date().toISOString()
        };
    }

    importData(data) {
        if (data.users) {
            this.users = data.users;
            this.saveUsers();
        }
        if (data.categories) {
            this.categories = data.categories;
            this.saveCategories();
        }
        if (data.posts) {
            this.posts = data.posts;
            this.savePosts();
        }
    }

    // Clear all data
    clearAllData() {
        localStorage.removeItem('fileshare_users');
        localStorage.removeItem('fileshare_categories');
        localStorage.removeItem('fileshare_posts');
        localStorage.removeItem('fileshare_current_user');
        
        this.users = [];
        this.categories = [];
        this.posts = [];
        this.currentUser = null;
        
        this.initializeDefaultData();
    }
}
