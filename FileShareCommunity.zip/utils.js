// Utility functions for FileShare Community
class Utils {
    // Generate unique ID
    static generateId() {
        return Date.now().toString(36) + Math.random().toString(36).substr(2);
    }

    // Validate email format
    static isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    // Escape HTML to prevent XSS
    static escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    // Format date for display
    static formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('pt-BR') + ' às ' + date.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
    }

    // Format file size
    static formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    // Get file extension
    static getFileExtension(filename) {
        return filename.slice((filename.lastIndexOf('.') - 1 >>> 0) + 2);
    }

    // Get file type icon
    static getFileTypeIcon(filename) {
        const ext = this.getFileExtension(filename).toLowerCase();
        const icons = {
            // Documents
            'pdf': '📄',
            'doc': '📝',
            'docx': '📝',
            'txt': '📄',
            'rtf': '📄',
            
            // Images
            'jpg': '🖼️',
            'jpeg': '🖼️',
            'png': '🖼️',
            'gif': '🖼️',
            'bmp': '🖼️',
            'svg': '🖼️',
            
            // Videos
            'mp4': '🎬',
            'avi': '🎬',
            'mov': '🎬',
            'wmv': '🎬',
            'flv': '🎬',
            'mkv': '🎬',
            
            // Audio
            'mp3': '🎵',
            'wav': '🎵',
            'flac': '🎵',
            'aac': '🎵',
            'ogg': '🎵',
            
            // Archives
            'zip': '📦',
            'rar': '📦',
            '7z': '📦',
            'tar': '📦',
            'gz': '📦',
            
            // Code
            'js': '📋',
            'html': '📋',
            'css': '📋',
            'php': '📋',
            'py': '📋',
            'java': '📋',
            'cpp': '📋',
            'c': '📋',
            
            // Spreadsheets
            'xls': '📊',
            'xlsx': '📊',
            'csv': '📊',
            
            // Presentations
            'ppt': '📺',
            'pptx': '📺'
        };
        
        return icons[ext] || '📁';
    }

    // Validate file type
    static isValidFileType(filename, allowedTypes) {
        if (!allowedTypes || allowedTypes.length === 0) return true;
        
        const ext = this.getFileExtension(filename).toLowerCase();
        return allowedTypes.includes(ext);
    }

    // Validate file size
    static isValidFileSize(fileSize, maxSize) {
        return fileSize <= maxSize;
    }

    // Debounce function
    static debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }

    // Throttle function
    static throttle(func, limit) {
        let inThrottle;
        return function() {
            const args = arguments;
            const context = this;
            if (!inThrottle) {
                func.apply(context, args);
                inThrottle = true;
                setTimeout(() => inThrottle = false, limit);
            }
        };
    }

    // Deep clone object
    static deepClone(obj) {
        if (obj === null || typeof obj !== 'object') return obj;
        if (obj instanceof Date) return new Date(obj.getTime());
        if (obj instanceof Array) return obj.map(item => this.deepClone(item));
        if (typeof obj === 'object') {
            const clonedObj = {};
            for (const key in obj) {
                if (obj.hasOwnProperty(key)) {
                    clonedObj[key] = this.deepClone(obj[key]);
                }
            }
            return clonedObj;
        }
    }

    // Show notification
    static showNotification(message, type = 'info', duration = 3000) {
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.textContent = message;
        
        // Add styles
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 15px 20px;
            border-radius: 5px;
            color: white;
            font-weight: 500;
            z-index: 10000;
            opacity: 0;
            transform: translateX(100%);
            transition: all 0.3s ease;
        `;
        
        // Set background color based on type
        switch (type) {
            case 'success':
                notification.style.backgroundColor = '#27ae60';
                break;
            case 'error':
                notification.style.backgroundColor = '#e74c3c';
                break;
            case 'warning':
                notification.style.backgroundColor = '#f39c12';
                break;
            default:
                notification.style.backgroundColor = '#3498db';
        }
        
        document.body.appendChild(notification);
        
        // Show animation
        setTimeout(() => {
            notification.style.opacity = '1';
            notification.style.transform = 'translateX(0)';
        }, 100);
        
        // Hide after duration
        setTimeout(() => {
            notification.style.opacity = '0';
            notification.style.transform = 'translateX(100%)';
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 300);
        }, duration);
    }

    // Copy to clipboard
    static async copyToClipboard(text) {
        try {
            await navigator.clipboard.writeText(text);
            this.showNotification('Copiado para a área de transferência!', 'success');
            return true;
        } catch (err) {
            console.error('Erro ao copiar:', err);
            this.showNotification('Erro ao copiar', 'error');
            return false;
        }
    }

    // Download file (simulate)
    static downloadFile(filename, content, mimeType = 'application/octet-stream') {
        const blob = new Blob([content], { type: mimeType });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }

    // Local storage helpers
    static setLocalStorage(key, value) {
        try {
            localStorage.setItem(key, JSON.stringify(value));
            return true;
        } catch (err) {
            console.error('Erro ao salvar no localStorage:', err);
            return false;
        }
    }

    static getLocalStorage(key, defaultValue = null) {
        try {
            const item = localStorage.getItem(key);
            return item ? JSON.parse(item) : defaultValue;
        } catch (err) {
            console.error('Erro ao ler do localStorage:', err);
            return defaultValue;
        }
    }

    static removeLocalStorage(key) {
        try {
            localStorage.removeItem(key);
            return true;
        } catch (err) {
            console.error('Erro ao remover do localStorage:', err);
            return false;
        }
    }

    // Form validation helpers
    static validateForm(form, rules) {
        const errors = {};
        
        for (const [field, fieldRules] of Object.entries(rules)) {
            const input = form.querySelector(`[name="${field}"]`);
            if (!input) continue;
            
            const value = input.value.trim();
            
            for (const rule of fieldRules) {
                if (rule.required && !value) {
                    errors[field] = rule.message || `${field} é obrigatório`;
                    break;
                }
                
                if (rule.minLength && value.length < rule.minLength) {
                    errors[field] = rule.message || `${field} deve ter pelo menos ${rule.minLength} caracteres`;
                    break;
                }
                
                if (rule.maxLength && value.length > rule.maxLength) {
                    errors[field] = rule.message || `${field} deve ter no máximo ${rule.maxLength} caracteres`;
                    break;
                }
                
                if (rule.pattern && !rule.pattern.test(value)) {
                    errors[field] = rule.message || `${field} tem formato inválido`;
                    break;
                }
                
                if (rule.custom && !rule.custom(value)) {
                    errors[field] = rule.message || `${field} é inválido`;
                    break;
                }
            }
        }
        
        return {
            isValid: Object.keys(errors).length === 0,
            errors
        };
    }

    // URL helpers
    static getUrlParams() {
        const params = new URLSearchParams(window.location.search);
        const result = {};
        for (const [key, value] of params) {
            result[key] = value;
        }
        return result;
    }

    static setUrlParam(key, value) {
        const url = new URL(window.location);
        url.searchParams.set(key, value);
        window.history.replaceState({}, '', url);
    }

    static removeUrlParam(key) {
        const url = new URL(window.location);
        url.searchParams.delete(key);
        window.history.replaceState({}, '', url);
    }
}

// Make Utils available globally
window.Utils = Utils;
