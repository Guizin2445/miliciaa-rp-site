// Authentication system for FileShare Community
class AuthSystem {
    constructor() {
        this.storage = new StorageManager();
        this.init();
    }

    init() {
        // Check if we're on login or register page
        if (window.location.pathname.includes('login.html')) {
            this.initLogin();
        } else if (window.location.pathname.includes('register.html')) {
            this.initRegister();
        }
    }

    initLogin() {
        const loginForm = document.getElementById('loginForm');
        if (loginForm) {
            loginForm.addEventListener('submit', (e) => this.handleLogin(e));
        }
    }

    initRegister() {
        const registerForm = document.getElementById('registerForm');
        if (registerForm) {
            registerForm.addEventListener('submit', (e) => this.handleRegister(e));
        }
    }

    async handleLogin(e) {
        e.preventDefault();
        
        const formData = new FormData(e.target);
        const email = formData.get('email');
        const password = formData.get('password');

        try {
            const user = this.storage.authenticateUser(email, password);
            if (user) {
                // Set current user session
                this.storage.setCurrentUser(user);
                
                // Redirect to dashboard
                window.location.href = 'dashboard.html';
            } else {
                this.showError('Email ou senha incorretos');
            }
        } catch (error) {
            this.showError('Erro ao fazer login: ' + error.message);
        }
    }

    async handleRegister(e) {
        e.preventDefault();
        
        const formData = new FormData(e.target);
        const username = formData.get('username');
        const email = formData.get('email');
        const password = formData.get('password');
        const confirmPassword = formData.get('confirmPassword');

        // Validate form
        if (!this.validateRegisterForm(username, email, password, confirmPassword)) {
            return;
        }

        try {
            // Check if user already exists
            if (this.storage.userExists(email)) {
                this.showError('Usuário já existe com este email');
                return;
            }

            // Create new user
            const newUser = {
                id: this.generateId(),
                username: username,
                email: email,
                password: password, // In a real app, this would be hashed
                role: 'user', // Default role
                createdAt: new Date().toISOString(),
                isActive: true
            };

            // Save user
            this.storage.createUser(newUser);
            
            this.showSuccess('Usuário registrado com sucesso! Você pode fazer login agora.');
            
            // Clear form
            e.target.reset();
            
            // Redirect to login after 2 seconds
            setTimeout(() => {
                window.location.href = 'login.html';
            }, 2000);

        } catch (error) {
            this.showError('Erro ao registrar usuário: ' + error.message);
        }
    }

    validateRegisterForm(username, email, password, confirmPassword) {
        // Clear previous errors
        this.hideError();
        
        // Validate username
        if (!username || username.length < 3) {
            this.showError('Nome de usuário deve ter pelo menos 3 caracteres');
            return false;
        }

        // Validate email
        if (!email || !this.isValidEmail(email)) {
            this.showError('Email inválido');
            return false;
        }

        // Validate password
        if (!password || password.length < 6) {
            this.showError('Senha deve ter pelo menos 6 caracteres');
            return false;
        }

        // Validate password confirmation
        if (password !== confirmPassword) {
            this.showError('Senhas não coincidem');
            return false;
        }

        return true;
    }

    isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    generateId() {
        return Date.now().toString(36) + Math.random().toString(36).substr(2);
    }

    showError(message) {
        const errorDiv = document.getElementById('error-message');
        if (errorDiv) {
            errorDiv.textContent = message;
            errorDiv.style.display = 'block';
            
            // Hide success message if shown
            this.hideSuccess();
        }
    }

    showSuccess(message) {
        const successDiv = document.getElementById('success-message');
        if (successDiv) {
            successDiv.textContent = message;
            successDiv.style.display = 'block';
            
            // Hide error message if shown
            this.hideError();
        }
    }

    hideError() {
        const errorDiv = document.getElementById('error-message');
        if (errorDiv) {
            errorDiv.style.display = 'none';
        }
    }

    hideSuccess() {
        const successDiv = document.getElementById('success-message');
        if (successDiv) {
            successDiv.style.display = 'none';
        }
    }
}

// Initialize authentication system when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new AuthSystem();
});
