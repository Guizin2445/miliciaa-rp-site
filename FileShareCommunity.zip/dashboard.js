// Dashboard management for FileShare Community
class DashboardManager {
    constructor() {
        this.storage = new StorageManager();
        this.currentUser = this.storage.getCurrentUser();
        this.activeCategory = null;
        this.editingUserId = null;
        
        this.init();
    }

    init() {
        // Check if user is logged in
        if (!this.currentUser) {
            window.location.href = 'login.html';
            return;
        }

        this.setupEventListeners();
        this.renderUserInfo();
        this.renderCategories();
        this.renderWelcomeScreen();
        this.checkPermissions();
    }

    setupEventListeners() {
        // Logout button
        document.getElementById('logoutBtn').addEventListener('click', () => this.logout());

        // Category creation
        const createCategoryBtn = document.getElementById('createCategoryBtn');
        if (createCategoryBtn) {
            createCategoryBtn.addEventListener('click', () => this.showCreateCategoryModal());
        }

        // Post creation
        const createPostBtn = document.getElementById('createPostBtn');
        if (createPostBtn) {
            createPostBtn.addEventListener('click', () => this.showCreatePostModal());
        }

        // Admin buttons
        const manageUsersBtn = document.getElementById('manageUsersBtn');
        if (manageUsersBtn) {
            manageUsersBtn.addEventListener('click', () => this.showUserManagement());
        }

        // User creation button
        const createUserBtn = document.getElementById('createUserBtn');
        if (createUserBtn) {
            createUserBtn.addEventListener('click', () => this.showCreateUserModal());
        }

        // Modal handlers
        this.setupModalHandlers();
    }

    setupModalHandlers() {
        // Category modal
        const closeCategoryModal = document.getElementById('closeCategoryModal');
        const cancelCategoryBtn = document.getElementById('cancelCategoryBtn');
        const categoryForm = document.getElementById('categoryForm');

        if (closeCategoryModal) {
            closeCategoryModal.addEventListener('click', () => this.hideModal('categoryModal'));
        }
        if (cancelCategoryBtn) {
            cancelCategoryBtn.addEventListener('click', () => this.hideModal('categoryModal'));
        }
        if (categoryForm) {
            categoryForm.addEventListener('submit', (e) => this.handleCreateCategory(e));
        }

        // Post modal
        const closePostModal = document.getElementById('closePostModal');
        const cancelPostBtn = document.getElementById('cancelPostBtn');
        const postForm = document.getElementById('postForm');
        const postImage = document.getElementById('postImage');

        if (closePostModal) {
            closePostModal.addEventListener('click', () => this.hideModal('postModal'));
        }
        if (cancelPostBtn) {
            cancelPostBtn.addEventListener('click', () => this.hideModal('postModal'));
        }
        if (postForm) {
            postForm.addEventListener('submit', (e) => this.handleCreatePost(e));
        }
        if (postImage) {
            postImage.addEventListener('change', (e) => this.handleImagePreview(e));
        }

        // User modal
        const closeUserModal = document.getElementById('closeUserModal');
        const cancelUserBtn = document.getElementById('cancelUserBtn');
        const userForm = document.getElementById('userForm');

        if (closeUserModal) {
            closeUserModal.addEventListener('click', () => this.hideModal('userModal'));
        }
        if (cancelUserBtn) {
            cancelUserBtn.addEventListener('click', () => this.hideModal('userModal'));
        }
        if (userForm) {
            userForm.addEventListener('submit', (e) => this.handleCreateUser(e));
        }

        // Close modal on background click
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('modal')) {
                this.hideModal(e.target.id);
            }
        });
    }

    renderUserInfo() {
        document.getElementById('currentUserName').textContent = this.currentUser.username;
        document.getElementById('currentUserRole').textContent = this.currentUser.role;
        document.getElementById('welcomeUserName').textContent = this.currentUser.username;
    }

    renderCategories() {
        const categoryList = document.getElementById('categoryList');
        const categories = this.storage.getAllCategories();
        
        categoryList.innerHTML = '';
        
        categories.forEach(category => {
            const li = document.createElement('li');
            li.innerHTML = `
                <a href="#" data-category-id="${category.id}">
                    ${category.name}
                    ${this.currentUser.role === 'admin' ? 
                        `<button class="delete-category-btn" data-category-id="${category.id}" title="Deletar categoria">×</button>` : 
                        ''
                    }
                </a>
            `;
            categoryList.appendChild(li);
        });

        // Add event listeners to category links
        categoryList.addEventListener('click', (e) => {
            if (e.target.matches('a[data-category-id]')) {
                e.preventDefault();
                const categoryId = e.target.dataset.categoryId;
                this.showCategory(categoryId);
            }
            
            if (e.target.matches('.delete-category-btn')) {
                e.preventDefault();
                e.stopPropagation();
                const categoryId = e.target.dataset.categoryId;
                this.deleteCategory(categoryId);
            }
        });
    }

    renderWelcomeScreen() {
        document.getElementById('welcomeScreen').style.display = 'block';
        document.getElementById('postsContainer').style.display = 'none';
        document.getElementById('userManagement').style.display = 'none';
        document.getElementById('contentTitle').textContent = 'Bem-vindo ao Dashboard';
        document.getElementById('createPostBtn').style.display = 'none';
    }

    showCategory(categoryId) {
        this.activeCategory = categoryId;
        const category = this.storage.getCategoryById(categoryId);
        
        if (!category) return;

        // Update active category in UI
        document.querySelectorAll('.category-list a').forEach(link => {
            link.classList.remove('active');
        });
        document.querySelector(`a[data-category-id="${categoryId}"]`).classList.add('active');

        // Update content
        document.getElementById('welcomeScreen').style.display = 'none';
        document.getElementById('userManagement').style.display = 'none';
        document.getElementById('postsContainer').style.display = 'block';
        document.getElementById('contentTitle').textContent = category.name;
        
        // Show create post button for poster and admin
        if (this.currentUser.role === 'poster' || this.currentUser.role === 'admin') {
            document.getElementById('createPostBtn').style.display = 'block';
        }

        this.renderPosts(categoryId);
    }

    renderPosts(categoryId) {
        const postsContainer = document.getElementById('postsContainer');
        const posts = this.storage.getPostsByCategory(categoryId);
        
        if (posts.length === 0) {
            postsContainer.innerHTML = `
                <div class="welcome-screen">
                    <h3>Nenhuma postagem encontrada</h3>
                    <p>Seja o primeiro a compartilhar conteúdo nesta categoria!</p>
                </div>
            `;
            return;
        }

        postsContainer.innerHTML = '';
        
        posts.forEach(post => {
            const postUser = this.storage.getUserById(post.userId);
            const canDelete = this.currentUser.role === 'admin' || post.userId === this.currentUser.id;
            
            const postElement = document.createElement('div');
            postElement.className = 'post-card';
            postElement.innerHTML = `
                <div class="post-header">
                    <div>
                        <h3 class="post-title">${this.escapeHtml(post.title)}</h3>
                        <div class="post-meta">
                            Por ${postUser ? postUser.username : 'Usuário desconhecido'} • 
                            ${this.formatDate(post.createdAt)}
                        </div>
                    </div>
                    <div class="post-actions">
                        ${canDelete ? `<button class="btn btn-outline btn-sm delete-post-btn" data-post-id="${post.id}">Deletar</button>` : ''}
                    </div>
                </div>
                <div class="post-content">
                    <p>${this.escapeHtml(post.description)}</p>
                    
                    ${post.imageUrl ? `<img src="${post.imageUrl}" alt="Post image" class="post-image">` : ''}
                    
                    ${post.fileName ? `
                        <div class="post-file">
                            <div class="post-file-icon">📁</div>
                            <div class="post-file-name">${this.escapeHtml(post.fileName)}</div>
                            <a href="#" class="post-file-link" onclick="alert('Download simulado: ${this.escapeHtml(post.fileName)}')">
                                Baixar arquivo
                            </a>
                        </div>
                    ` : ''}
                </div>
            `;
            
            postsContainer.appendChild(postElement);
        });

        // Add event listeners for delete buttons
        postsContainer.addEventListener('click', (e) => {
            if (e.target.matches('.delete-post-btn')) {
                const postId = e.target.dataset.postId;
                this.deletePost(postId);
            }
        });
    }

    showUserManagement() {
        if (this.currentUser.role !== 'admin') return;

        document.getElementById('welcomeScreen').style.display = 'none';
        document.getElementById('postsContainer').style.display = 'none';
        document.getElementById('userManagement').style.display = 'block';
        document.getElementById('contentTitle').textContent = 'Gerenciar Usuários';
        document.getElementById('createPostBtn').style.display = 'none';

        // Clear active category
        document.querySelectorAll('.category-list a').forEach(link => {
            link.classList.remove('active');
        });

        this.renderUsers();
    }

    renderUsers() {
        const usersTableBody = document.getElementById('usersTableBody');
        const users = this.storage.getAllUsers();
        
        usersTableBody.innerHTML = '';
        
        users.forEach(user => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${this.escapeHtml(user.username)}</td>
                <td>${this.escapeHtml(user.email)}</td>
                <td>
                    <span class="role-badge ${user.role}">${user.role}</span>
                </td>
                <td>
                    <div class="user-actions">
                        ${user.id !== this.currentUser.id ? `
                            <button class="btn btn-outline btn-sm edit-user-btn" data-user-id="${user.id}">Editar</button>
                            <button class="btn btn-outline btn-sm delete-user-btn" data-user-id="${user.id}">Deletar</button>
                        ` : '<em>Você</em>'}
                    </div>
                </td>
            `;
            usersTableBody.appendChild(tr);
        });

        // Add event listeners for user actions
        usersTableBody.addEventListener('click', (e) => {
            if (e.target.matches('.edit-user-btn')) {
                const userId = e.target.dataset.userId;
                this.editUser(userId);
            }
            if (e.target.matches('.delete-user-btn')) {
                const userId = e.target.dataset.userId;
                this.deleteUser(userId);
            }
        });
    }

    updateUserRole(userId, newRole) {
        const user = this.storage.updateUser(userId, { role: newRole });
        if (user) {
            this.renderUsers();
            this.showSuccessMessage(`Cargo do usuário ${user.username} atualizado para ${newRole}`);
        }
    }

    showCreateUserModal() {
        if (this.currentUser.role !== 'admin') return;
        
        this.editingUserId = null;
        document.getElementById('userModalTitle').textContent = 'Criar Usuário';
        document.getElementById('saveUserBtn').textContent = 'Criar';
        document.getElementById('editUserId').value = '';
        document.getElementById('userForm').reset();
        this.showModal('userModal');
    }

    editUser(userId) {
        if (this.currentUser.role !== 'admin') return;
        
        const user = this.storage.getUserById(userId);
        if (!user) return;
        
        this.editingUserId = userId;
        document.getElementById('userModalTitle').textContent = 'Editar Usuário';
        document.getElementById('saveUserBtn').textContent = 'Salvar';
        document.getElementById('editUserId').value = userId;
        document.getElementById('userUsername').value = user.username;
        document.getElementById('userEmail').value = user.email;
        document.getElementById('userPassword').value = user.password;
        document.getElementById('userRole').value = user.role;
        this.showModal('userModal');
    }

    deleteUser(userId) {
        if (this.currentUser.role !== 'admin') return;
        
        const user = this.storage.getUserById(userId);
        if (!user) return;
        
        if (confirm(`Tem certeza que deseja deletar o usuário ${user.username}?`)) {
            this.storage.deleteUser(userId);
            this.renderUsers();
            this.showSuccessMessage(`Usuário ${user.username} deletado com sucesso`);
        }
    }

    handleCreateUser(e) {
        e.preventDefault();
        
        if (this.currentUser.role !== 'admin') return;
        
        const formData = new FormData(e.target);
        const username = formData.get('userUsername');
        const email = formData.get('userEmail');
        const password = formData.get('userPassword');
        const role = formData.get('userRole');
        const editUserId = formData.get('editUserId');

        // Validate form
        if (!username.trim() || !email.trim() || !password.trim()) {
            this.showErrorMessage('Todos os campos são obrigatórios');
            return;
        }

        if (!this.isValidEmail(email)) {
            this.showErrorMessage('Email inválido');
            return;
        }

        // Check if editing or creating
        if (editUserId) {
            // Editing existing user
            const existingUser = this.storage.getUserByEmail(email);
            if (existingUser && existingUser.id !== editUserId) {
                this.showErrorMessage('Email já está em uso por outro usuário');
                return;
            }

            const updatedUser = this.storage.updateUser(editUserId, {
                username: username.trim(),
                email: email.trim(),
                password: password.trim(),
                role: role
            });

            if (updatedUser) {
                this.renderUsers();
                this.hideModal('userModal');
                this.showSuccessMessage(`Usuário ${username} atualizado com sucesso`);
            }
        } else {
            // Creating new user
            if (this.storage.userExists(email)) {
                this.showErrorMessage('Email já está em uso');
                return;
            }

            const newUser = {
                id: this.storage.generateId(),
                username: username.trim(),
                email: email.trim(),
                password: password.trim(),
                role: role,
                createdAt: new Date().toISOString(),
                isActive: true
            };

            this.storage.createUser(newUser);
            this.renderUsers();
            this.hideModal('userModal');
            this.showSuccessMessage(`Usuário ${username} criado com sucesso`);
        }
    }

    isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    showCreateCategoryModal() {
        if (this.currentUser.role !== 'admin') return;
        this.showModal('categoryModal');
    }

    showCreatePostModal() {
        if (this.currentUser.role !== 'poster' && this.currentUser.role !== 'admin') return;
        if (!this.activeCategory) {
            alert('Selecione uma categoria primeiro');
            return;
        }
        this.showModal('postModal');
    }

    handleCreateCategory(e) {
        e.preventDefault();
        
        const formData = new FormData(e.target);
        const name = formData.get('categoryName');
        const description = formData.get('categoryDescription');

        if (!name.trim()) {
            alert('Nome da categoria é obrigatório');
            return;
        }

        const category = {
            id: this.storage.generateId(),
            name: name.trim(),
            description: description.trim(),
            createdAt: new Date().toISOString(),
            createdBy: this.currentUser.id
        };

        this.storage.createCategory(category);
        this.renderCategories();
        this.hideModal('categoryModal');
        e.target.reset();
    }

    handleCreatePost(e) {
        e.preventDefault();
        
        const formData = new FormData(e.target);
        const title = formData.get('postTitle');
        const description = formData.get('postDescription');
        const file = formData.get('postFile');
        const image = formData.get('postImage');

        if (!title.trim() || !description.trim()) {
            alert('Título e descrição são obrigatórios');
            return;
        }

        const post = {
            id: this.storage.generateId(),
            title: title.trim(),
            description: description.trim(),
            categoryId: this.activeCategory,
            userId: this.currentUser.id,
            createdAt: new Date().toISOString(),
            fileName: file && file.name ? file.name : null,
            imageUrl: null
        };

        // Handle image upload (simulate)
        if (image && image.size > 0) {
            const reader = new FileReader();
            reader.onload = (e) => {
                post.imageUrl = e.target.result;
                this.storage.createPost(post);
                this.renderPosts(this.activeCategory);
            };
            reader.readAsDataURL(image);
        } else {
            this.storage.createPost(post);
            this.renderPosts(this.activeCategory);
        }

        this.hideModal('postModal');
        e.target.reset();
        document.getElementById('imagePreview').style.display = 'none';
    }

    handleImagePreview(e) {
        const file = e.target.files[0];
        const preview = document.getElementById('imagePreview');
        
        if (file) {
            const reader = new FileReader();
            reader.onload = (e) => {
                preview.innerHTML = `<img src="${e.target.result}" alt="Preview">`;
                preview.style.display = 'block';
            };
            reader.readAsDataURL(file);
        } else {
            preview.style.display = 'none';
        }
    }

    deleteCategory(categoryId) {
        if (this.currentUser.role !== 'admin') return;
        
        if (confirm('Tem certeza que deseja deletar esta categoria? Todas as postagens serão removidas.')) {
            this.storage.deleteCategory(categoryId);
            this.renderCategories();
            
            if (this.activeCategory === categoryId) {
                this.renderWelcomeScreen();
                this.activeCategory = null;
            }
        }
    }

    deletePost(postId) {
        const post = this.storage.getPostById(postId);
        if (!post) return;
        
        const canDelete = this.currentUser.role === 'admin' || post.userId === this.currentUser.id;
        if (!canDelete) return;
        
        if (confirm('Tem certeza que deseja deletar esta postagem?')) {
            this.storage.deletePost(postId);
            this.renderPosts(this.activeCategory);
        }
    }

    checkPermissions() {
        // Show/hide admin features
        if (this.currentUser.role === 'admin') {
            document.getElementById('adminActions').style.display = 'block';
            document.getElementById('adminPanel').style.display = 'block';
        }

        // Show/hide post creation for poster and admin
        if (this.currentUser.role === 'poster' || this.currentUser.role === 'admin') {
            // Post creation button will be shown when a category is selected
        }
    }

    showModal(modalId) {
        document.getElementById(modalId).style.display = 'block';
    }

    hideModal(modalId) {
        document.getElementById(modalId).style.display = 'none';
    }

    logout() {
        this.storage.clearCurrentUser();
        window.location.href = 'index.html';
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('pt-BR') + ' às ' + date.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
    }

    showSuccessMessage(message) {
        Utils.showNotification(message, 'success');
    }

    showErrorMessage(message) {
        Utils.showNotification(message, 'error');
    }
}

// Initialize dashboard when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new DashboardManager();
});
